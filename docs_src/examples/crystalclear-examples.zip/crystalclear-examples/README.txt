CRYSTALClear examples
=====================

Real CRYSTAL calculations to try CRYSTALClear on, the same files the example
notebooks of the documentation use (https://crystaldevs.github.io/CRYSTALClear/).

spectra/thiourea_pbed3_Ahlrichs-pVTZ_freqcalc.out
    A frequency calculation of thiourea, with IR intensities.

electronic/mgo_band.BAND
electronic/mgo_doss_totalao.DOSS
    The band structure and the density of states of MgO, written by PROPERTIES.

elastic/coesite_ela.out
    An elastic constants calculation of coesite.

Run the examples of the Usage page from this folder, so that the paths in them
are found as they are written.
